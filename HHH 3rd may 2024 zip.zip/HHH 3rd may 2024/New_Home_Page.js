document.addEventListener("DOMContentLoaded", function() {
    var searchButton = document.getElementById("searchButton");

    searchButton.addEventListener("click", function() {
        search();
    });

    function search() {
        var selectedDisease = document.getElementById("categorySelect").value;
        var table = document.getElementById("resultTable");
        var resultBody = document.getElementById("resultBody");
        var container = document.querySelector(".container");

        // Clear previous results
        resultBody.innerHTML = "";
        container.querySelectorAll("table.drug-details").forEach(function(table) {
            table.remove();
        });

        // Fetch data based on selected disease
        // Example data
        var data = [];

        switch(selectedDisease.toLowerCase()) {
            case "breast cancer":
                data = [
                    { Mild: "	Tamoxifen", Chronic: "Doxorubicin" },
                    { Mild: "letrozol ", Chronic: "Paclitaxel " },
                    { Mild: "Lapatinib ", Chronic: "Capecitabine" },
                    { Mild: "Neratinib ", Chronic: "Cyclophosphamide" },
                    { Mild: "Palbociclib ", Chronic: "Carboplatin " },
                    { Mild: "Abemaciclib ", Chronic: "Evista " },
                    { Mild: "Pertuzumab ", Chronic: "Epirubicin " },
                    { Mild: "Trastuzumab ", Chronic: "Fluorouracil " },
                ];
                break;
                case "pcod":
                    data = [
                      { Mild: "Clomiphene ", Chronic: "Acarbose" },
                      { Mild: " Eflornithine", Chronic: "Desogestrel " },
                      { Mild: " Metformin ", Chronic: "Finasteride" },
                      { Mild: " Metformin ", Chronic: "Flutamide" },
                      { Mild: " Drospirenone ", Chronic: "Letrozole" },
                      { Mild: " Liraglutide", Chronic: " Sibutramine " },
                      { Mild: " Pioglitazone", Chronic: "Drospirenone " },
                      { Mild: "  Rosiglitazone ", Chronic: "Ethinylestradiol Plus Levonorgestrel " },
                      { Mild: "  Spironolactone", Chronic: " " },
                        ];
                    break;
                  case "thyroid":
                    data = [
                      { Mild: "Levothyroxine/liothyronine ", Chronic: "Levothyroxine" },
                      { Mild: " Cytomel ", Chronic: "Liothyronine" },
                      { Mild: " Tirosint ", Chronic: "Methimazole " },
                      { Mild: " Thyroglobulin ", Chronic: "Propylthiouracil" },
                      { Mild: " Thyroxine", Chronic: " Thyroid desiccated  " },
                      { Mild: "Euthyrox ", Chronic: " Liotrix " },
                      { Mild: " Selenomethionine", Chronic: " Radioactive iodine " },
                      { Mild: " Unithroid  ", Chronic: "Carbimazole " },
                        ];
                    break;
                  case "cervical cancer":
                    data = [
                      { Mild: "Acetaminophen  ", Chronic: "Cisplatin" },
                      { Mild: " Ibuprofen  ", Chronic: "Carboplatin" },
                      { Mild: " Naproxen  ", Chronic: "Paclitaxel" },
                      { Mild: " Ondansetron  ", Chronic: "Topotecan" },
                      { Mild: "Metoclopramide  ", Chronic: " Gemcitabine " },
                      { Mild: "Dexamethasone ", Chronic: "Gemcitabine " },
                      { Mild: " Lorazepam   ", Chronic: " Docetaxel" },
                      { Mild: " Diphenhydramine  ", Chronic: " Irinotecan" },
                        ];
                    break;
                  case "uterian fibroids":
                    data = [
                      { Mild: "Halofuginone ", Chronic: "Anastrozole " },
                      { Mild: " Pirfenidone ", Chronic: "Myfembree" },
                      { Mild: " acetaminophen ", Chronic: "Ulipristal Acetate" },
                      { Mild: "mifepristone  ", Chronic: "Oriahnn" },
                      { Mild: "fadrozole ", Chronic: " Leuprolide " },
                      { Mild: " asoprisnil", Chronic: " Ulipristal" },
                      { Mild: "  vilaprisan ", Chronic: " Goserelin" },
                      { Mild: "Tranexamic acid ", Chronic: " Triplorelin" },
                        ];
                    break;
                  default:
                    break;
        }

        // Populate table with fetched data
        for (var i = 0; i < data.length; i++) {
            var row = document.createElement("tr");
            row.innerHTML = "<td>" + data[i].Mild + "</td><td>" + data[i].Chronic + "</td>";
            resultBody.appendChild(row);
        }

        // Show the table
        table.style.display = "table";

        // Add event listener to cells for additional drug details
        var cells = document.querySelectorAll("#resultBody td");
        cells.forEach(function(cell) {
            cell.addEventListener("click", function() {
                var drugName = cell.textContent.trim();
                showDrugDetails(drugName);
            });
        });
    }

    // Function to display additional drug details for the selected medication
    function showDrugDetails(drugName) {
        // Object containing drug details for each medication
        var drugDetails = {
            "Tamoxifen": {
                "Drug Name": "Tamoxifen",
                "Receptor": "Estrogen receptors.",
                "LogP Value": "6.35",
                "Chemical Formula":"C2H29NO",
                "Half Life":"5 to 7 days.",
                "Adverse Effects":"1.leg cramps   \n 2.hair thinning or hair loss. \n3.feeling light headed. \n4.eye problems, such as blurred vision, due to damage of the retina or cataracts. an allergic reaction. \n5. headaches. \n6.diarrhoea. \n7.itchiness on or around the vulval area",
                "Food Interactions":"•	This herb induces CYP3A4 metabolism, which may reduce the serum concentration of tamoxifen. Take with a full glass of water. Take with or without food",
                "Dosage form":"20 to 40 mg orally daily for 5 years; doses greater than 20 mg should be given in divided doses. To reduce the incidence of breast cancer in women at high risk for breast cancer: 20 mg orally daily for 5 years",
                "Marketed preparation":"Nolvadex tablets, . liquid (brand name):  Soltamox",
                "Alternatives":"anastrozole, exemestane, Other SERMs, such as raloxifene, fulvestrant."
            },
            "Doxorubicin": {
                "Drug Name": "Doxorubicin",
                "Receptor": "GPR91 Receptor.",
                "LogP Value": "0.53.",
                "Chemical Formula":"C27H29NO11",
                "Half Life":"20 hours to 48 hours",
                "Adverse Effects":"diarrhoea Nausea Hair loss, Bleeding, Breathlessness Mouth, Haematuria, Tiredness, Melena, Chest pain, Cough, Irregular heartbeat, Pain at the injection site, Painful or difficult urination, Fever, Lungs, Red spots, Sore throat",
                "Food Interactions":"Avoid St. John's Wort. This herb induces CYP3A4 metabolism, which may reduce the serum concentration of doxorubicin. Exercise caution with grapefruit products. Grapefruit inhibits CYP3A4 metabolism, which may increase the serum concentration of doxorubicin",
                "Dosage form":"injectable solution- 2mg/mL powder for injection-10mg,50mg",
                "Marketed preparation":"Adriamycin",
                "Alternatives":"Verzenio (abemaciclib)	Ibrance (palbociclib)"
            },
            "letrozole": {
                "Drug Name": "letrozole",
                "Receptor": "Hormone receptor (HR).",
                "LogP Value": "1.8 –2.95.",
                "Chemical Formula":"C17H11N5",
                "Half Life":"approximately 42h in healthy volunteers, but longer in breast cancer patients ",
                "Adverse Effects":"similar to the menopause such as hot flushes, difficulty sleeping, tiredness and low mood, but these usually improve during the first months of taking it. However, if the symptoms are severe or last longer than a few months",
                "Food Interactions":"Take with or without food. Food slows absorption without decreasing the quantity absorbed",
                "Dosage form":"tablet 2.5mg",
                "Marketed preparation":"sold under the brand name Femara",
                "Alternatives":"tamoxifen, anastrozole and exemestane."
            },
            "Paclitaxel": {
                "Drug Name": "Paclitaxel",
                "Receptor": "toll-like receptor 4 (TLR4).",
                "LogP Value": "3.96.",
                "Chemical Formula":"C47H51NO14",
                "Half Life":"When a 24 hour infusion of 135 mg/m^2 is given to ovarian cancer patients, the elimination half=life is 52.7 hours",
                "Adverse Effects":"Tingling, Joint pain, Bruising and bleeding, Diarrhea, Dizziness, Hair loss, Mouth sores, Anxiety, Fast heartbeat, Nausea, Feeling sick, High blood pressure, Itching, Low blood pressure, Painful or difficult urination, Pale skin, Melena, Breathlessness, Nail changes, Sore mouth, Blurred or double vision, Changes in liver function, Chest pain, Chills",
                "Food Interactions":"Avoid echinacea. Co-administration may decrease the effectiveness of immunosuppressants, and echinacea may induce CYP3A4 increasing paclitaxel metabolism.Exercise caution with grapefruit products. Grapefruit inhibits CYP3A4 metabolism, which may increase the serum concentration of paclitaxel.Exercise caution with St. John's Wort. This herb induces the CYP3A4 metabolism of paclitaxel and may reduce its serum concentration.",
                "Dosage form": "injectable solution- 6mg/mL",
                "Marketed Preparation": "Taxol",
                "Alternatives": "Docetaxel and nab-paclitaxel"
            },
            "Lapatinib": {
                "Drug Name": "Lapatinib",
                "Receptor": "Lapatinib is an oral, small-molecule, reversible inhibitor of both epidermal growth factor receptor (EGFR) and human epidermal growth factor receptor-2 (HER2) tyrosine kinases..",
                "LogP Value": "4.64.",
                "Chemical Formula":"C29H26ClFN4O4S",
                "Half Life":"Single-dose terminal half life: 14.2 hours Effective multiple-dose half life: 24 hours",
                "Adverse Effects":"avoid if having blistering, peeling, or loosening of the skin, red skin lesions, severe acne or skin rash, sores or ulcers on the skin, or fever or chills while you are using this medicine. Serious skin reactions",
                "Food Interactions":"Avoid grapefruit products. Grapefruit may reduce the CYP3A4 metabolism of lapatinib, increasing its serum levels.  Take separate from meals. Take lapatinib at least 1 hour before or after eating, as lapatinib bioavailability is elevated by food.",
                "Dosage Form": "tablet 250mg",
                "Marketed Preparation": "Tykerb and Tyverb marketed by Novartis",
                "Alternatives": "Anastrozole, Tamoxifen, Letrozole, Arimidex. Exemestane, Palbociclib"
            },
            "Capecitabine": {
                "Drug Name": "Capecitabine",
                "Receptor": "hormone receptor-positive relative to hormone receptor-negative metastatic breast cancer.",
                "LogP Value": "0.0338.",
                "Chemical Formula":"C15H22FN3O6",
                "Half Life":"0.4 h, and in man 0.5 h.",
                "Adverse Effects":"Abdominal pain, Constipation, Diarrhoea, Dizziness, Headache, Vomiting, Bleeding, Mouth ulcer, Trouble sleeping, Hair loss, Back pain, Bloody nose, Blurred vision, Cold, Confusion, Conjunctivitis, Cough producing mucus, Anorexia, Dehydration, Skin rash, Taste changes, Weakness, Blood in the urine or stools, Bone pain",
                "Food Interactions":"Take at the same time every day. Take XELODA 2 times a day at the same time each day, about 12 hours apart. Take with food. Take XELODA within 30 minutes after finishing a meal. Take with plain water. Swallow XELODA tablets whole with water. Do not chew, cut, or crush XELODA tablets",
                "Dosage Form": "tablet 150mg 500mg",
                "Marketed Preparation": "Capecitabine, sold under the brand name Xeloda ",
                "Alternatives": "Ibrance (palbociclib)	Letrozole"
            },
            "Neratinib": {
                "Drug Name": "Neratinib",
                "Receptor": "dual inhibitor of the tyrosine kinase receptors, erbB1 (EGFR) and erbB2 (HER2).",
                "LogP Value": "5.36.",
                "Chemical Formula":"C30H29Cl1N6O3",
                "Half Life":"The mean half life of elimination ranges from 7-17 h following a single dose [FDA Label]. The mean plasma half life during multiple doses is 14.6 h for neratinib, 21.6 h for M3, 13.8 h for M6, and 10.4 h for M7",
                "Adverse Effects":"Nausea, vomiting, mouth sores/pain, stomach/abdominal pain, loss of appetite, weight loss, tiredness, dry skin, nail changes, or muscle spasms",
                "Food Interactions":"Avoid grapefruit products. Grapefruit inhibits CYP3A metabolism, which may increase the serum concentration of neratinib. Exercise caution with St. John's Wort. This herb induces CYP3A metabolism and may reduce serum levels of neratinib. Take at the same time every day. Take separate from antacids. Take antacids at least 3 hours before or after neratinib. Take with food",
                "Dosage Form": "tablet-40mg (equivalent to 48.31mg neratinib       maleate",
                "Marketed Preparation": "40 mg neratinib (equivalent to 48.31 mg of neratinib maleate). Film-coated, red, oval shaped and debossed with 'W104' on one side and plain on the other side.",
                "Alternatives": "Femara. Herceptin. Paclitaxel. Soltamox. Epirubicin"
                
            },
            "Cyclophosphamide": {
                "Drug Name": "Cyclophosphamide",
                "Receptor": ":  cytochrome P450 isoforms, CYP2A6, 2B6, 3A4, 3A5, 2C9, 2C18, and 2C19.",
                "LogP Value": "0.097.",
                "Chemical Formula":"C7H15Cl2N2O2P",
                "Half Life":"3 to 12 hours",
                "Adverse Effects":"Nausea, Loss of appetite, Hair loss, Nail changes, Shortness of breath, Diarrhoea, Mouth sores, Bleeding, Frequent urination, Haematuria, Chills, Fast heartbeat, Abdominal pain, Irritability and restlessness, Fatigue, Urinary tract and renal toxicity, Breathlessness and looking pale, Heart disease, Infection, Joint pain, Liver disease, Low back pain, Lung disease, Missing menstrual periods",
                "Food Interactions":"Avoid grapefruit and grapefruit juice for 48 hours before and on day of your cyclophosphamide dose as it may interact with cyclophosphamide",
                "Dosage Form": "powder for injection 500mg; 1g; 2g Tablet 25mg 50mg",
                "Marketed Preparation": "Cyclophosphamide was initially commercially available as the monohydrate, in a parenteral dosage pre-mix consisting of a sterile, packaged, dry-powder admixture of the drug and sodium chloride",
                "Alternatives": "Ibrance (palbociclib)	Kisqali (ribociclib)"
            },
            "Palbociclib": {
                "Drug Name": "Palbociclib",
                "Receptor": ": Human epidermal growth factor receptor type 2 (HER2)-negative and hormone receptor(HR)-positive tumours .",
                "LogP Value": "2.12.",
                "Chemical Formula":"C24H29N7O2",
                "Half Life":"29 hours",
                "Adverse Effects":"allergic reactions like skin rash, itching or hives, swelling of the face, lips, or tongue. breathing problems. cough.",
                "Food Interactions":"Avoid grapefruit products. Avoid St. John's Wort. Take with food.",
                "Dosage Form": "capsule 75mg 100mg 125mg   tablet 75mg 100mg 125mg",
                "Marketed Preparation": "IBRANCE 75 mg hard capsules",
                "Alternatives": "Letrozole, Intravenous powder for injection"
            },
            "Carboplatin": {
                "Drug Name": "Carboplatin",
                "Receptor": "tyrosine kinase receptor.",
                "LogP Value": "0.04.",
                "Chemical Formula":"C6H12N2O4Pt",
                "Half Life":"The distribution half life of carboplatin is 1.1-2 hours, and the elimination half life was2.6-5.9 hours",
                "Adverse Effects":"Constipation, Hair loss, Infection, Bleeding, Kidney changes, Paresthesia, Hearing changes, Vomiting, Weakness, Allergic reactions, Diarrhoea, Injection site reactions, Mouth sores, Pain, Breathlessness, Fatigue, Feeling or being sick, Loss of appetite, Rash, Tummy pain, Blood in urine or stools, Blurred vision",
                "Food Interactions":"Avoid echinacea. Co-administration may decrease effectiveness of immunosuppressants.",
                "Dosage Form": "lyophilized powder for reconstitution 150mg  injectable solution 10mg/mL (in vials of 50, 150, 450, and 600 mg)",
                "Marketed Preparation": "sterile, pyrogen-free, 10 mg/mL aqueous solution of carboplatin, USP",
                "Alternatives": "Fluorouracil	Doxorubicin"
            },
            "Abemaciclib": {
                "Drug Name": "Abemaciclib",
                "Receptor": "Hormone receptor positive (HR+).",
                "LogP Value": "4.42.",
                "Chemical Formula":"C27H32F2N8",
                "Half Life":"18.3 hours (72% CV)",
                "Adverse Effects":"pain or tenderness in the upper stomach, pale stools, dark urine, loss of appetite, nausea, vomiting, or yellow eyes or skin.",
                "Food Interactions":"Avoid grapefruit products. Grapefruit inhibits CYP3A metabolism, which may increase the serum concentration of abemaciclib. Avoid St. John's Wort. This herb induces CYP3A metabolism and may reduce serum levels of abemaciclib.Take at the same time every day. Take with or without food",
                "Dosage Form": "tablet 50mg 100mg 150mg 200mg",
                "Marketed Preparation": "VERZENIO",
                "Alternatives": "Ibrance(palbociclib)"
            },
            "Evista": {
                "Drug Name": "Evista",
                "Receptor": "selective estrogen receptor modulator with an estrogen-agonistic effect on bone receptors.",
                "LogP Value": "5.45.",
                "Chemical Formula":"C28H27NO4S",
                "Half Life":"27 to 32 hours",
                "Adverse Effects":"hot flashes, flu-like symptoms, muscle spasms, arthralgia, and infection",
                "Food Interactions":"Avoid excessive or chronic alcohol consumption. Excessive and chronic alcohol consumption may be associated with vitamin D deficiency. Take with or without food. The absorption is unaffected by food",
                "Dosage Form": "tablet 60mg",
                "Marketed Preparation": "Evista tablet ",
                "Alternatives": "Alendronate	Fosamax (alendronate)"
            },
            "Pertuzumab": {
                "Drug Name": "Pertuzumab",
                "Receptor": "2 protein (HER2).",
                "LogP Value": "0.264.",
                "Chemical Formula":"C17H27NO2",
                "Half Life":"18 days based on a population pharmacokinetic analysis",
                "Adverse Effects":"Heart problems, including those without symptoms (such as reduced heart function) and those with symptoms (such as congestive heart failure). Receiving PERJETA during pregnancy can result in the death of an unborn baby and birth defects.",
                "Food Interactions":"no interaction.",
                "Dosage Form": "injectable solution •	30mg/mL(420mg/14 mL)",
                "Marketed Preparation": " Perjeta",
                "Alternatives": ": i. Verzenio (abemaciclib)  ii. Ibrance(palbociclib) "
            },
            "Epirubicin": {
                "Drug Name": "Epirubicin",
                "Receptor": "anthracycline topoisomerase II inhibitor.",
                "LogP Value": "0.53.",
                "Chemical Formula":"C27H29NO11",
                "Half Life":"30 to 40 hours",
                "Adverse Effects":"Hair loss, Diarrhea, Mouth sores and ulcers, Nausea, Changes to nails, Discoloured urine, Fatigue, Bleeding, Missed menstrual periods, Skin changes, Stomach pain, Cardiac toxicity, Chills, Heart arrhythmia, Feeling of warmth, Swelling, Tissue hypoxia, Cough, Chest pain, High fever, Hives, Hot flashes, Skin rash, Lower back or side pain",
                "Food Interactions":"Drink plenty of fluids. Increased fluid intake increases urine output and the excretion of uric acid. ",
                "Dosage Form": "injectable solution-2mg/mL as single dose vial containing 50mg/25mL or 200mg/100mL",
                "Marketed Preparation": "Each ml contains 2 mg epirubicin hydrochloride",
                "Alternatives": "Tamoxifen	Letrozole"
            },
            "Trastuzumab": {
                "Drug Name": "Trastuzumab",
                "Receptor": "HER2 receptor positive.",
                "LogP Value": "0.35.",
                "Chemical Formula":"C6448H9948N1720O2012S44 · 2 Oligosaccharid-Reste · (C47H61ClN4O13S)n (n = ca. 3,5)",
                "Half Life":"The terminal half-life is approximately 28 days, but may decrease with lower doses - at the 10mg and 500mg doses, half-lives averaged approximately 1.7 and 12 days, respectively",
                "Adverse Effects":"Headache. Chills. Gastrointestinal symptoms (nausea and vomiting; abdominal pain, diarrhea) Cough. Back pain. Upper respiratory symptoms (rhinitis, pharyngitis) Weakness and fatigue",
                "Food Interactions":"The terminal half-life is approximately 28 days, but may decrease with lower doses - at the 10mg and 500mg doses, half-lives averaged approximately 1.7 and 12 days, respectively",
                "Dosage Form": "injection, powder for reconstitution •	150mg/single-dose vial (Herceptin, Hercessi, Ontruzant) •	420mg/multidose vial (Herceptin, Ogivri, Herzuma, Trazimera, Kanjinti, Ontruzant)",
                "Marketed Preparation": "brand name Herceptin",
                "Alternatives": "Verzenio (abemaciclib)	Ibrance (palbociclib)"
            },
            "Fluorouracil": {
                "Drug Name": "Fluorouracil",
                "Receptor": "Epidermal Growth Factor Receptor .",
                "LogP Value": "-0.66.",
                "Chemical Formula":"C4H3FN2O2",
                "Half Life":"8 to 20 minutes.",
                "Adverse Effects":"Altered mental status, confusion, disorientation, intense feelings of joy, difficulty walking and balancing, coma. Allergic reaction which may cause rash, low blood pressure, wheezing, shortness of breath, swelling of the face or throat. Blood clot which may cause swelling, pain, or shortness of breath.",
                "Food Interactions":"Products containing folic acid may increase the effects of fluorouracil. You may be more likely to develop serious side effects such as anaemia, bleeding problems, infections, and nerve damage when these medications are used together.",
                "Dosage Form": "injectable solution •	50mg/mL (500mg/10mL single-dose vial)",
                "Marketed Preparation": "sold under the brand name Adrucil among others, is a cytotoxic chemotherapy medication used to treat cancer.",
                "Alternatives": "Carac, Tolak, Fluoroplex, Aminolevulinic acid topical, Klisyri, Ameluz"
            },
            "Clomiphene": {
                "Drug Name": "Clomiphene",
                "Receptor": "selective estrogen receptor modulator.",
                "LogP Value": "  4",
                "Chemical Formula":"C26H28ClNO",
                "Half Life":"5 to 7 days.",
                "Adverse Effects":"Ovarian hyperstimulation syndrome—stomach or pelvic pain, bloating, nausea, vomiting, diarrhea, weight gain.",
                "Food Interactions":"•	Take with or without food. The absorption is unaffected by food.",
                "Dosage form":"Tablet 50mg.",
                "Marketed preparation":"Clomid 50",
                "Alternatives":"Tamoxifen, glumetza.."
            } ,
            "Acarbose": {
                "Drug Name": "Acarbose",
                "Receptor": "competitively and reversibly inhibits both pancreatic alpha-amylase and membrane-bound alpha-glucosidases - of the alpha-glucosidases, inhibitory        potency appears to follow a rank order of glucoamylase > sucrase > maltase > isomaltase.",
                "LogP Value": "-3.29",
                "Chemical Formula":"C25H43NO18 ",
                "Half Life":"2 hours",
                "Adverse Effects":"signs of liver problems (such as nausea/vomiting that doesn't stop, loss of appetite, stomach/abdominal pain, yellowing eyes/skin, dark urine).",
                "Food Interactions":"Take with food. Each dose should be taken with the first bite of a main meal.	",
                "Dosage form":"Tablet 25, 50, 100 mg",
                "Marketed preparation":"Glucobay, Precose",
                "Alternatives":"GlucoGon, GlucoPure"
            },
            "Eflornithine": {
                "Drug Name": "Eflornithine",
                "Receptor": "Irreversible inhibitor of the enzyme ornithine decarboxylase .",
                "LogP Value": "-3.1 to -2.9",
                "Chemical Formula":"C6H12F2N2O2",
                "Half Life":"3.5 hours.",
                "Adverse Effects":": stinging, burning, or tingling of the skin. redness of the skin..",
                "Food Interactions":"Take with or without food	",
                "Dosage form":"Cream 4170mg/30g Tablet 250mg",
                "Marketed preparation":"Florexa (cream)  Iwilfin , Vaniqa",
                "Alternatives":"Vaniqa."  
            },
            "Desogestrel": {
                "Drug Name": "Desogestrel",
                "Receptor": ": Binding selectively to the progesterone receptor and generating low androgenic activity.",
                "LogP Value": "3.5 to 4.0",
                "Chemical Formula":"C22H30O",
                "Half Life":"30 hours",
                "Adverse Effects":"Breast abnormalities; depressed mood; headache; libido decreased; menstrual cycle irregularities; mood altered; nausea; skin reactions",
                "Food Interactions":"Moderate Food Interaction",
                "Dosage form":"Tablet (0.075mg)",
                "Marketed preparation":"Alenvona, Apri, Azalia, Azurette, Bekyree",
                "Alternatives":"Nexplanone, NuvaRing, Sprintec." 
            },
            "Metformin": {
                "Drug Name": "Metformin",
                "Receptor": "AMP-activated protein kinase",
                "LogP Value": "-1.43.",
                "Chemical Formula":"C4H11N5",
                "Half Life":"6.2 hours in the plasma and in the blood is approximately 17.6 hours.",
                "Adverse Effects":":  lactic acidosis, allergies, hypoglycemia, vitamin B12 deficiency, altered taste, and gastrointestinal intolerance.",
                "Food Interactions":"Avoid alcohol. Take with food. Food reduces irritation.	",
                "Dosage form":"Tablet 500mg, 850mg, 1000mg",
                "Marketed preparation":"Bci Metformin. Fortamet, Glucophage",
                "Alternatives":"Berbaprime"   
            },
            "Finasteride": {
                "Drug Name": "Finasteride",
                "Receptor": "competitive and specific inhibitor of Type II 5α-reductase, a nuclear-bound steroid intracellular enzyme primarily located in the prostatic stromal cell that converts the androgen testosterone into the more active metabolite",
                "LogP Value": "3.1",
                "Chemical Formula":"C23H36N2O2",
                "Half Life":"3 to 16 hours",
                "Adverse Effects":"Chills, cold sweats, Confusion, dizziness, faintness, or lightheadedness when getting up suddenly from a lying or sitting position",
                "Food Interactions":"Take with or without food. The absorption is unaffected by food.",
                "Dosage form":"Tablet (1, 5 mg)",
                "Marketed preparation":"Act Finasteride, M-finasteride",
                "Alternatives":"Minoxidil, Dutasteride"   
            },
            "Drospirenone": {
                "Drug Name": "Drospirenone",
                "Receptor": "Suppress the release of follicle stimulating hormone (FSH) and luteinizing hormone (LH), preventing ovulation.",
                "LogP Value": "3.7",
                "Chemical Formula":"C24H30O3",
                "Half Life":"30 hours",
                "Adverse Effects":"Allergic reactions—skin rash, itching, hives, swelling of the face, lips, tongue, or throat",
                "Food Interactions":"Avoid St. John's Wort. Take at the same time every day. Take with or without food.	",
                "Dosage form":"Tablet (4 mg)",
                "Marketed preparation":"Slynd",
                "Alternatives":"Nexplanone, NuvaRing, Sprintec"   
            },
            "Flutamide": {
                "Drug Name": "Flutamide",
                "Receptor": "potent inhibitor of testosterone-stimulated prostatic DNA synthesis.",
                "LogP Value": "3.01",
                "Chemical Formula":"C11H11F3N2O3 ",
                "Half Life":"6 hours",
                "Adverse Effects":"Hot flashes, loss of sexual interest/ability, diarrhea, nausea, vomiting, and enlargement of male breasts",
                "Food Interactions":"Take with or without food. The absorption is unaffected by food.",
                "Dosage form":"Tablet , Capsule (125 , 250 mg)",
                "Marketed preparation":"Euflex , Eulexin , Flutamide",
                "Alternatives":"Zytiga, Lupron Depot, Xtandi, Erleada"   
            },
            "Liraglutide": {
                "Drug Name": "Liraglutide",
                "Receptor": "Agonist of the glucagon-like peptide-1 receptor which is coupled to adenylate cyclase. Slows gastric emptying to increase control of blood sugar",
                "LogP Value": "-2.8 to -3.1",
                "Chemical Formula":"C172H265N43O51",
                "Half Life":"13 hours",
                "Adverse Effects":"nausea, diarrhea, vomiting, decreased appetite, indigestion, and constipation",
                "Food Interactions":"Take with or without food.	",
                "Dosage form":"Injection , Solution (6mg/ml)",
                "Marketed preparation":"Victoza, Saxenda",
                "Alternatives":"Topiramate, Semaglutide, Tirzepatide" 
            },
            "Letrozole": {
                "Drug Name": "Letrozole",
                "Receptor": "Blocks the active site, and therefore the electron transfer chain of CYP19A1. This competitive inhibition prevents the conversion of androgens to estrogen",
                "LogP Value": "2.92",
                "Chemical Formula":"C17H11N5",
                "Half Life":"42h in healthy volunteers",
                "Adverse Effects":"hot flushes, difficulty sleeping, tiredness and low mood",
                "Food Interactions":"Take with or without food. Food slows absorption without decreasing the quantity absorbed.",
                "Dosage form":"Tablet 2.5 mg",
                "Marketed preparation":"Co letrozole, Femara, Nra letrozole",
                "Alternatives":"Fempro, Stimufol, Letsi, Letoval"   
            },
            "Rosiglitazone": {
                "Drug Name": "Rosiglitazone",
                "Receptor": "Agonist at peroxisome proliferator activated receptors",
                "LogP Value": "3.7",
                "Chemical Formula":" C18H19N3O3S",
                "Half Life":"3 to 4 Hours.",
                "Adverse Effects":"edema, hypertension, heart failure/congestive heart failure, myocardial ischemia, diarrhea, upper respiratory tract infection. .",
                "Food Interactions":"Take with or without food.	",
                "Dosage form":"Tablet 2, 4 , 8 mg",
                "Marketed preparation":"Avandia",
                "Alternatives":"Ozempic, Rybelsus , Semaglutide."   
            },
            "Sibutramine": {
                "Drug Name": "Sibutramine",
                "Receptor": "Inhibition of norepinephrine (NE), serotonin (5-hydroxytryptamine, 5-HT), and to a lesser extent, dopamine reuptake at the neuronal synapse. ",
                "LogP Value": ": 5.3",
                "Chemical Formula":"C17H26ClN",
                "Half Life":"1.1 hours",
                "Adverse Effects":" Dry mouth, headache, insomnia, asthenia, obstipation and in some cases amnesia ",
                "Food Interactions":"Using sibutramine with alcohol can increase the risk of cardiovascular side effects such as increased heart rate, chest pain, or blood pressure changes.	",
                "Dosage form":"Capsule (5, 10, 15 mg)",
                "Marketed preparation":"Meridia",
                "Alternatives":"Topiramate, Semaglutide, Adipex- P."   
            },
            "Drospirenone": {
                "Drug Name": "Drospirenone",
                "Receptor": "Suppress the release of follicle stimulating hormone (FSH) and luteinizing hormone (LH), preventing ovulation.",
                "LogP Value": "3.7",
                "Chemical Formula":"C24H30O3",
                "Half Life":"30 hours",
                "Adverse Effects":"Allergic reactions—skin rash, itching, hives, swelling of the face, lips, tongue, or throat.",
                "Food Interactions":": Avoid St. John's Wort. Take at the same time every day. Take with or without food.	",
                "Dosage form":"Tablet (4 mg)",
                "Marketed preparation":"Slynd",
                "Alternatives":"Nexplanone, NuvaRing, Sprintec."   
            },
            "Pioglitazone": {
                "Drug Name": "Pioglitazone",
                "Receptor": "Activation of PPARγ increases the transcription of insulin-responsive genes involved in the control of glucose and lipid production, transport, and utilization.",
                "LogP Value": "1.5 to 2.1",
                "Chemical Formula":"C19H20N2O3S",
                "Half Life":"3-7 hours",
                "Adverse Effects":"weight gain, pedal edema, bone loss and precipitation of congestive heart failure in at-risk individuals, without any increase in CVD/all-cause mortality",
                "Food Interactions":" Take with or without food. Food delays drug absorption, but not to a clinically significant extent.",
                "Dosage form":"Tablet (15, 30, 45 mg)",
                "Marketed preparation":"Act Pioglitazone, Actos",
                "Alternatives":"Ozempic, Rybelsus, Semaglutide"  
            },
            "Ethinylestradiol Plus Levonorgestrel": {
                "Drug Name": "Ethinylestradiol Plus Levonorgestrel",
                "Receptor": "binds to progesterone and androgen receptors and slows the release of gonadotropin-releasing hormone (GnRH) from the hypothalamus",
                "LogP Value": "3.2 to 3.7",
                "Chemical Formula":"C21H28O2",
                "Half Life":"0.75 mg dose of 1.5 mg of levonorgestrel ranges between 20-60 hours",
                "Adverse Effects":"alterations of menstrual bleeding patterns, nausea, abdominal/pelvic pain, headache/migraine, dizziness, fatigue, amenorrhea, ovarian cysts, genital discharge, acne/seborrhea, breast tenderness, and vulvovaginitis",
                "Food Interactions":"Grapefruit juice may increase the blood levels of certain medications such as levonorgestrel",
                "Dosage form":"Intrauterine device",
                "Marketed preparation":"Jaydess, Kyleena, Liletta ",
                "Alternatives":"Take Action, My Way, Option 2, Preventeza, AfterPill, My Choice, Aftera, and EContra"  
            },
            "Levothyroxine": {
                "Drug Name": "Levothyroxine",
                "Receptor": "Levothyroxine primarily binds to and activates the thyroid hormone receptors, including thyroid hormone receptor alpha (TRα) and thyroid hormone receptor beta (TRβ) ",
                "LogP Value": "3.73",
                "Chemical Formula":"C15H11I4NO4",
                "Half Life":"",
                "Adverse Effects":".",
                "Food Interactions":"•	",
                "Dosage form":"",
                "Marketed preparation":"",
                "Alternatives":"."  
            },
            "Ethinylestradiol Plus Levonorgestrel": {
                "Drug Name": "Acarbose",
                "Receptor": ".",
                "LogP Value": "",
                "Chemical Formula":"",
                "Half Life":".",
                "Adverse Effects":".",
                "Food Interactions":"•	",
                "Dosage form":"",
                "Marketed preparation":"",
                "Alternatives":"."  
            },
            "Ethinylestradiol Plus Levonorgestrel": {
                "Drug Name": "Acarbose",
                "Receptor": ".",
                "LogP Value": "",
                "Chemical Formula":"",
                "Half Life":".",
                "Adverse Effects":".",
                "Food Interactions":"•	",
                "Dosage form":"",
                "Marketed preparation":"",
                "Alternatives":"."  
            },
            "Ethinylestradiol Plus Levonorgestrel": {
                "Drug Name": "Acarbose",
                "Receptor": ".",
                "LogP Value": "",
                "Chemical Formula":"",
                "Half Life":".",
                "Adverse Effects":".",
                "Food Interactions":"•	",
                "Dosage form":"",
                "Marketed preparation":"",
                "Alternatives":"."  
            },
            "Ethinylestradiol Plus Levonorgestrel": {
                "Drug Name": "Acarbose",
                "Receptor": ".",
                "LogP Value": "",
                "Chemical Formula":"",
                "Half Life":".",
                "Adverse Effects":".",
                "Food Interactions":"•	",
                "Dosage form":"",
                "Marketed preparation":"",
                "Alternatives":"."  
            },
            "Ethinylestradiol Plus Levonorgestrel": {
                "Drug Name": "Acarbose",
                "Receptor": ".",
                "LogP Value": "",
                "Chemical Formula":"",
                "Half Life":".",
                "Adverse Effects":".",
                "Food Interactions":"•	",
                "Dosage form":"",
                "Marketed preparation":"",
                "Alternatives":"."  
            },
            "Ethinylestradiol Plus Levonorgestrel": {
                "Drug Name": "Acarbose",
                "Receptor": ".",
                "LogP Value": "",
                "Chemical Formula":"",
                "Half Life":".",
                "Adverse Effects":".",
                "Food Interactions":"•	",
                "Dosage form":"",
                "Marketed preparation":"",
                "Alternatives":"."  
            },
            "Ethinylestradiol Plus Levonorgestrel": {
                "Drug Name": "Acarbose",
                "Receptor": ".",
                "LogP Value": "",
                "Chemical Formula":"",
                "Half Life":".",
                "Adverse Effects":".",
                "Food Interactions":"•	",
                "Dosage form":"",
                "Marketed preparation":"",
                "Alternatives":"."  
            },
            "Ethinylestradiol Plus Levonorgestrel": {
                "Drug Name": "Acarbose",
                "Receptor": ".",
                "LogP Value": "",
                "Chemical Formula":"",
                "Half Life":".",
                "Adverse Effects":".",
                "Food Interactions":"•	",
                "Dosage form":"",
                "Marketed preparation":"",
                "Alternatives":"."  
            },
            "Ethinylestradiol Plus Levonorgestrel": {
                "Drug Name": "Acarbose",
                "Receptor": ".",
                "LogP Value": "",
                "Chemical Formula":"",
                "Half Life":".",
                "Adverse Effects":".",
                "Food Interactions":"•	",
                "Dosage form":"",
                "Marketed preparation":"",
                "Alternatives":"."  
            },
            "Ethinylestradiol Plus Levonorgestrel": {
                "Drug Name": "Acarbose",
                "Receptor": ".",
                "LogP Value": "",
                "Chemical Formula":"",
                "Half Life":".",
                "Adverse Effects":".",
                "Food Interactions":"•	",
                "Dosage form":"",
                "Marketed preparation":"",
                "Alternatives":"."  
            },
            "Ethinylestradiol Plus Levonorgestrel": {
                "Drug Name": "Acarbose",
                "Receptor": ".",
                "LogP Value": "",
                "Chemical Formula":"",
                "Half Life":".",
                "Adverse Effects":".",
                "Food Interactions":"•	",
                "Dosage form":"",
                "Marketed preparation":"",
                "Alternatives":"."  
            },
            "Ethinylestradiol Plus Levonorgestrel": {
                "Drug Name": "Acarbose",
                "Receptor": ".",
                "LogP Value": "",
                "Chemical Formula":"",
                "Half Life":".",
                "Adverse Effects":".",
                "Food Interactions":"•	",
                "Dosage form":"",
                "Marketed preparation":"",
                "Alternatives":"."  
            },
            "Ethinylestradiol Plus Levonorgestrel": {
                "Drug Name": "Acarbose",
                "Receptor": ".",
                "LogP Value": "",
                "Chemical Formula":"",
                "Half Life":".",
                "Adverse Effects":".",
                "Food Interactions":"•	",
                "Dosage form":"",
                "Marketed preparation":"",
                "Alternatives":"."  
            },
            "Ethinylestradiol Plus Levonorgestrel": {
                "Drug Name": "Acarbose",
                "Receptor": ".",
                "LogP Value": "",
                "Chemical Formula":"",
                "Half Life":".",
                "Adverse Effects":".",
                "Food Interactions":"•	",
                "Dosage form":"",
                "Marketed preparation":"",
                "Alternatives":"."  
            },
            "Ethinylestradiol Plus Levonorgestrel": {
                "Drug Name": "Acarbose",
                "Receptor": ".",
                "LogP Value": "",
                "Chemical Formula":"",
                "Half Life":".",
                "Adverse Effects":".",
                "Food Interactions":"•	",
                "Dosage form":"",
                "Marketed preparation":"",
                "Alternatives":"."  
            },
            " uterine fibroids Ethinylestradiol Plus Levonorgestrel": {
                "Drug Name": "Acarbose",
                "Receptor": ".",
                "LogP Value": "",
                "Chemical Formula":"",
                "Half Life":".",
                "Adverse Effects":".",
                "Food Interactions":"•	",
                "Dosage form":"",
                "Marketed preparation":"",
                "Alternatives":"."  
            },
            "Ethinylestradiol Plus Levonorgestrel": {
                "Drug Name": "Acarbose",
                "Receptor": ".",
                "LogP Value": "",
                "Chemical Formula":"",
                "Half Life":".",
                "Adverse Effects":".",
                "Food Interactions":"•	",
                "Dosage form":"",
                "Marketed preparation":"",
                "Alternatives":"."  
            },
            "Ethinylestradiol Plus Levonorgestrel": {
                "Drug Name": "Acarbose",
                "Receptor": ".",
                "LogP Value": "",
                "Chemical Formula":"",
                "Half Life":".",
                "Adverse Effects":".",
                "Food Interactions":"•	",
                "Dosage form":"",
                "Marketed preparation":"",
                "Alternatives":"."  
            },
            "Ethinylestradiol Plus Levonorgestrel": {
                "Drug Name": "Acarbose",
                "Receptor": ".",
                "LogP Value": "",
                "Chemical Formula":"",
                "Half Life":".",
                "Adverse Effects":".",
                "Food Interactions":"•	",
                "Dosage form":"",
                "Marketed preparation":"",
                "Alternatives":"."  
            },
            "Ethinylestradiol Plus Levonorgestrel": {
                "Drug Name": "Acarbose",
                "Receptor": ".",
                "LogP Value": "",
                "Chemical Formula":"",
                "Half Life":".",
                "Adverse Effects":".",
                "Food Interactions":"•	",
                "Dosage form":"",
                "Marketed preparation":"",
                "Alternatives":"."  
            },
            "Ethinylestradiol Plus Levonorgestrel": {
                "Drug Name": "Acarbose",
                "Receptor": ".",
                "LogP Value": "",
                "Chemical Formula":"",
                "Half Life":".",
                "Adverse Effects":".",
                "Food Interactions":"•	",
                "Dosage form":"",
                "Marketed preparation":"",
                "Alternatives":"."  
            },
            "Ethinylestradiol Plus Levonorgestrel": {
                "Drug Name": "Acarbose",
                "Receptor": ".",
                "LogP Value": "",
                "Chemical Formula":"",
                "Half Life":".",
                "Adverse Effects":".",
                "Food Interactions":"•	",
                "Dosage form":"",
                "Marketed preparation":"",
                "Alternatives":"."  
            },
            "Ethinylestradiol Plus Levonorgestrel": {
                "Drug Name": "Acarbose",
                "Receptor": ".",
                "LogP Value": "",
                "Chemical Formula":"",
                "Half Life":".",
                "Adverse Effects":".",
                "Food Interactions":"•	",
                "Dosage form":"",
                "Marketed preparation":"",
                "Alternatives":"."  
            },
            "Ethinylestradiol Plus Levonorgestrel": {
                "Drug Name": "Acarbose",
                "Receptor": ".",
                "LogP Value": "",
                "Chemical Formula":"",
                "Half Life":".",
                "Adverse Effects":".",
                "Food Interactions":"•	",
                "Dosage form":"",
                "Marketed preparation":"",
                "Alternatives":"."  
            },
            "Ethinylestradiol Plus Levonorgestrel": {
                "Drug Name": "Acarbose",
                "Receptor": ".",
                "LogP Value": "",
                "Chemical Formula":"",
                "Half Life":".",
                "Adverse Effects":".",
                "Food Interactions":"•	",
                "Dosage form":"",
                "Marketed preparation":"",
                "Alternatives":"."  
            },
            "Ethinylestradiol Plus Levonorgestrel": {
                "Drug Name": "Acarbose",
                "Receptor": ".",
                "LogP Value": "",
                "Chemical Formula":"",
                "Half Life":".",
                "Adverse Effects":".",
                "Food Interactions":"•	",
                "Dosage form":"",
                "Marketed preparation":"",
                "Alternatives":"."  
            },
            "Ethinylestradiol Plus Levonorgestrel": {
                "Drug Name": "Acarbose",
                "Receptor": ".",
                "LogP Value": "",
                "Chemical Formula":"",
                "Half Life":".",
                "Adverse Effects":".",
                "Food Interactions":"•	",
                "Dosage form":"",
                "Marketed preparation":"",
                "Alternatives":"."  
            },
            "Ethinylestradiol Plus Levonorgestrel": {
                "Drug Name": "Acarbose",
                "Receptor": ".",
                "LogP Value": "",
                "Chemical Formula":"",
                "Half Life":".",
                "Adverse Effects":".",
                "Food Interactions":"•	",
                "Dosage form":"",
                "Marketed preparation":"",
                "Alternatives":"."  
            },
            "Ethinylestradiol Plus Levonorgestrel": {
                "Drug Name": "Acarbose",
                "Receptor": ".",
                "LogP Value": "",
                "Chemical Formula":"",
                "Half Life":".",
                "Adverse Effects":".",
                "Food Interactions":"•	",
                "Dosage form":"",
                "Marketed preparation":"",
                "Alternatives":"."  
            },
            "Ethinylestradiol Plus Levonorgestrel": {
                "Drug Name": "Acarbose",
                "Receptor": ".",
                "LogP Value": "",
                "Chemical Formula":"",
                "Half Life":".",
                "Adverse Effects":".",
                "Food Interactions":"•	",
                "Dosage form":"",
                "Marketed preparation":"",
                "Alternatives":"."  
            },
            "Ethinylestradiol Plus Levonorgestrel": {
                "Drug Name": "Acarbose",
                "Receptor": ".",
                "LogP Value": "",
                "Chemical Formula":"",
                "Half Life":".",
                "Adverse Effects":".",
                "Food Interactions":"•	",
                "Dosage form":"",
                "Marketed preparation":"",
                "Alternatives":"."  
            },
            " Acetaminophen ": {
                "Drug Name": "Acetaminophen ",
                "Receptor": "",
                "LogP Value": "",
                "Chemical Formula":"",
                "Half Life":".",
                "Adverse Effects":".",
                "Food Interactions":"•	",
                "Dosage form":"",
                "Marketed preparation":"",
                "Alternatives":"."     
            },
            " cisplatin ": {
                "Drug Name": "Acetaminophen ",
                "Receptor": "",
                "LogP Value": "",
                "Chemical Formula":"",
                "Half Life":".",
                "Adverse Effects":".",
                "Food Interactions":"•	",
                "Dosage form":"",
                "Marketed preparation":"",
                "Alternatives":"."     
            },



        };

        // Create a new table for drug details
        var drugTable = document.createElement("table");
        drugTable.classList.add("drug-details");
        drugTable.innerHTML = `
        <table border="1" align="center">
        <thead>
            <tr>
                <th colspan="11">
                    <h3 style="text-align: center;">${drugName} </h3>
                </th>
            </tr>
            <tr>
                <th>Drug Name</th>
                <th>Receptor</th>
                <th>LogP Value</th>
                <th>Chemical Formula</th>
                <th>Half Life</th>
                <th>Adverse Effects</th>
                <th>Food Interactions</th>
                <th>Dosage Forms</th>
                <th>Marketed Preparations</th>
                <th>Alternatives</th>
            </tr> 
        </thead>
        <tbody>
            <tr>
                <td>${drugDetails[drugName]["Drug Name"]}</td>
                <td>${drugDetails[drugName]["Receptor"]}</td>
                <td>${drugDetails[drugName]["LogP Value"]}</td>
                <td>${drugDetails[drugName]["Chemical Formula"]}</td>
                <td>${drugDetails[drugName]["Half Life"]}</td>
                <td>${drugDetails[drugName]["Adverse Effects"]}</td>
                <td>${drugDetails[drugName]["Food Interactions"]}</td>
                <td>${drugDetails[drugName]["Dosage Form"]}</td>
                <td>${drugDetails[drugName]["Marketed Preparation"]}</td>
                <td>${drugDetails[drugName]["Alternatives"]}</td>
            </tr>
        </tbody>
    </table>
    
        `;

        // Clear previous drug details tables
        var container = document.querySelector(".container");
        container.querySelectorAll("table.drug-details").forEach(function(table) {
            table.remove();
        });

        // Append the drug details table below the main table
        container.appendChild(drugTable);
    }
});
